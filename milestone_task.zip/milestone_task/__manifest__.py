# -*- coding: utf-8 -*-
{
    'name':'Milestone Task',
    'version':'2.0',
    'depends':['base','mail','product','sale'],
    'category':'category',
    'author': "Afthab",
    'application':True,
    'license':'LGPL-3',
    'data':
    [
        'views/sale_order_line_view.xml'
    ],
}
